/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortalgorithms;

/**
 *
 * @author omoza
 */
public class Algorithms {
    
    //Method to swap elements of an array
    public static void numSwap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    //Method to output the elements of an array in a single string
    public static String arrNum(int[] arr) {
        String result = "";
        
        for(int i = 0; i < arr.length; i++) {
            result += String.valueOf(arr[i]) + ", ";
        }
        
        return result;
    }
    
    //QuickSort Method
    public static String quickSort(int[] arr, int n1, int n2) {
        String result = ""; //Creating the output variable
        
        //Checks the size of the array to determine whether to use quick sort or not
        if ((n2 - n1) > 3) {
            int midNum = n1 + (n2 - n1)/2;
            
            //Compares sections of the divided array and runs any relevant swaps
            if(arr[n1] > arr[midNum]) {
                numSwap(arr, n1, midNum);
                result += "New array: " + arrNum(arr) + "\n";
            }
            if (arr[midNum] > arr[n2]) {
                numSwap(arr,midNum,n2);
                result += "New array: " + arrNum(arr) + "\n";
            }
            if(arr[n1] > arr[midNum]) {
                numSwap(arr, n1, midNum);
                result += "New array: " + arrNum(arr) + "\n";
            }
            //A pivot is pivot is set for the quick sort algorithm to compare to
            numSwap(arr, midNum, n2 - 1);
            int pivot = arr[n2 - 1];
            result += "New array: " + arrNum(arr) + "\n";
            
            int indexFromLeft = n1 + 1;
            int indexFromRight = n2 - 2;
            boolean done = false; //Variable to end the sorting
            while (!done) {
                //Move from the left until an element greater than the pivot is found
                while (arr[indexFromLeft] < pivot) {
                    indexFromLeft++;
                }
                //Move from the right until the element is less than the pivot
                while (arr[indexFromRight] > pivot) {
                    indexFromRight--;
                }
                //Redunancy statement to ensure that the indexes are in proper positions
                if (indexFromLeft < indexFromRight) {
                    numSwap(arr, indexFromLeft, indexFromRight);
                    result += "New array: " + arrNum(arr) + "\n";
                    indexFromLeft++;
                    indexFromRight--;
                } else {
                    done = true;
                }
                result += "New array: " + arrNum(arr) + "\n";
            }
            
            numSwap(arr, n2 - 1, indexFromLeft);
            result += "New array: " + arrNum(arr) + "\n";
            //Sub-arrays are now sorted again with quick sort until selection sort is used
            quickSort(arr, n1, indexFromLeft - 1);
            quickSort(arr, indexFromLeft + 1, n2);
            result += "New array: " + arrNum(arr) + "\n";
        } else {
            selectionSortInternal(arr, n1, n2 + 1);
        }
        return result;
    }
    
    //Method to use selection sort within the quickSort method
    public static String selectionSortInternal(int[] arr, int n1, int n2) {
        String result = "";
        
        //Sort a between the beginning and end index
        //Start at the first index
        for (int i = n1; i < n2; i++) {
            //Find the smallest value
            int small = arr[i];
            int iSmall = i;
            //Find the smallest element
            for (int j = i + 1; j < n2; j++) {
                if (arr[j] < small) {
                    small = arr[j];
                    iSmall = j;
                }
            }
            
            if (i != iSmall) { //Swap until the first element is the smallest
                numSwap(arr, i, iSmall);
                result += "New Array: " + arrNum(arr) + "\n";
            }
            result += "New Array (Pass " + (i + 1) + "): " + arrNum(arr) + "\n";
        }
        return result;
    }
    
    //Standard selection sort for selection sort tab
    public static String selectionSort(int[] arr) {
        String result = "";
        
        int n1 = 0, n2 = arr.length;
        
        for (int i = n1; i < n2; i++) {
            int small = arr[i];
            int iSmall = i;
            for (int j = i + 1; j < n2; j++) {
                if (arr[j] < small) {
                    small = arr[j];
                    iSmall = j;
                }
            }
            if (i != iSmall) {
                numSwap(arr, i, iSmall);
                result += "New Array: " + arrNum(arr) + "\n";
            }
            
        }
        return result;
    }
    
    //Insertion Sort Method
    public static String insertionSort(int[] arr) {
        String result = "";
        
        int n1 = 0, n2 = arr.length;
        
        //Start at index first + 1
        for (int i = n1 + 1; i < n2; i++) {
            //Store the value
            int next = arr[i];
            //Start searching for where to insert
            int iFill = i - 1;
            while (iFill >= 0 && next < arr[iFill]) {
                arr[iFill + 1] = arr[iFill];
                iFill--;
            }
            arr[iFill + 1] = next;
            result += "New Array: " + arrNum(arr) + "\n";
        }
        return result;
    }
    
    //merge method to use in mergeSort
    public static String merge(int[] arr, int n1, int n2, int n3) {
        String result = "";
        int left = n1, right = n2 + 1, merge = 0;
        int partitionSize = n3 - n1 + 1;
        int[] temp = new int[partitionSize];
        
        while (left <= n2 && right <= n3) {
            if (arr[left] <= arr[right]) {
                temp[merge] = arr[left];
                ++left;
            }
            else {
                temp[merge] = arr[right];
                ++right;
            }
            ++merge;
        
        }
        
        while (left <= n2) {
            temp[merge] = arr[left];
            ++left;
            ++merge;
        }

        // If right partition is not empty, add remaining elements to merged numbers
        while (right <= n3) {
            temp[merge] = arr[right];
            ++right;
            ++merge;
        }

        // Copy merge number back to numbers
        for (merge = 0; merge < partitionSize; ++merge) {
            arr[n1 + merge] = temp[merge];
            result += "New array: " + arrNum(arr) + "\n";
        }
        
        
        return result;
    }
    
    //Merge Sort method method
    public static String mergeSort(int[] arr, int n1, int n2) {
        String result = "";
        int n3;
        
        if (n1 < n2) {
            n3 = (n1 + n2) / 2;  //Find midpoint

            //Sort left and right partitions
            mergeSort(arr, n1, n3);
            mergeSort(arr, n3 + 1, n2);

            //Merge partitions to be sorted
            result += merge(arr, n1, n3, n2).toString();
        }
    return result;
    }
}
