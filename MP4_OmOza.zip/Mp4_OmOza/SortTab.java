/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortalgorithms;

import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.layout.HBox;

/**
 *
 * @author omoza
 */
public class SortTab extends Tab {
    private Button genNum;
    private Button start;
    private Button reset;
    
    public SortTab(String str) {
        super(str);
        genNum = new Button("Generate New Numbers");
        start = new Button("Start Sorting");
        reset = new Button("Reset");
        
        //HBox buttons = new HBox(genNum,start,reset);
        //buttons.getChildren().add(genNum);
        //buttons.setLayoutX(50);
        //buttons.setLayoutY(50);
        
    }
    
}
