/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortalgorithms;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;

/**
 *
 * @author omoza
 */

public class SortPane extends TabPane {
    private SortTab[] tabs;
    private int nTabs;
    
    public SortPane(int nTabs) {
        this.nTabs = nTabs;
        
        tabs = new SortTab[nTabs];
        
    }
}
