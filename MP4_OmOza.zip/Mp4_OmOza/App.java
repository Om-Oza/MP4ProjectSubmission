package com.mycompany.sortalgorithms;

import java.util.ArrayList;
import java.util.Random;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage stage) {
        Random rand = new Random();
        
        TabPane sortPane = new TabPane();
        Tab intro = new Tab("Sorting Intro");
        Tab select = new Tab("Selection Sort");
        Tab insert = new Tab("Insertion Sort");
        Tab quick = new Tab("Quick Sort");
        Tab merge = new Tab("Merge Sort");
        
        Label introLabel = new Label();
        ArrayList<HBox> textFieldHBoxes = new ArrayList<>();
        ArrayList<Button> randGen = new ArrayList<>();
        ArrayList<Button> reset = new ArrayList<>();
        ArrayList<Button> start = new ArrayList<>();
        ArrayList<HBox> buttonArray = new ArrayList<>();
        ArrayList<TextField[]> numBoxes = new ArrayList<>();
        ArrayList<VBox> tabVBoxes = new ArrayList<>();
        Label[] tabLabels = new Label[5];
        Label[] sortSteps = new Label[4];
        HBox introTab = new HBox();
        
        String introString, selectDescription, insertDescription, quickDescription, mergeDescription;
        
        //Label for Intro Tab
        introString = "Four Sorting Algorithms:\n\n" +
                "These various algorithms will show how a program can sort out a set of " + 
                "numbers in sequential order, with the steps the program runs through to reach the final array.";
        
        //Put the String onto the tab
        introLabel.setText(introString);
        introTab.getChildren().add(introLabel);
        intro.setContent(introTab);
        
        //Creates a vBox for the sorting tabs
        for(int i = 0; i < 4; i++){
            VBox vBox = new VBox();
            vBox.setAlignment(Pos.TOP_CENTER);
            vBox.setSpacing(15);
            tabVBoxes.add(vBox);
        }
        
        
        //Labels for the sorting tabs
        selectDescription = "Selection Sort goes through a set of numbers and moves " +
                "the lowest number it finds to the beginning\n until it finishes the set and outputs a sorted array.";
        insertDescription = "Insertion Sort takes the number at each index of a " + 
                "set and compares it to all the numbers before it. \nIf it is smaller " + 
                "than the numbers that were already sorted, the program will move it " + 
                "up the sorted list until it arrives at the correct spot so the sorted list is once again in sequential order.";
        quickDescription = "Quick Sort is a method of sorting that divides a set of numbers at a certain number, called a pivot. " + 
                "\nOne side is less than the pivot and the other side is greater than the pivot number. " +
                "Each side is then considered a separate array and is sorted in a " + 
                "recursive manner with the Quick Sort method until the all the sub-arrays are sorted.";
        mergeDescription = "Merge Sort is a similar sortin method to the Quick Sort in that it takes the array of numbers" + 
                " and divides it into sub-arrays, which are broken down into single element arrays. \n" + 
                "Arrays are then compared with one another and combined into 2-number arrays with the elements in order. " + 
                "The sorting process continues and the arrays merge together, getting more sorted as they combine.";
        
        //Creates labels according to the strings
        tabLabels[0] = new Label(selectDescription);
        tabLabels[1] = new Label(insertDescription);
        tabLabels[2] = new Label(quickDescription);
        tabLabels[3] = new Label(mergeDescription);
        
        //Fills an hBox with the textfields that will hold the elements of the array
        for(int i = 0; i < 4; i++){
            HBox textFieldHBox = new HBox();
            numBoxes.add(new TextField[10]);
            for(int j = 0; j < 10; j++){
                TextField textField = new TextField();
                numBoxes.get(i)[j] = textField;
                textField.setOnAction(a -> {
                    try {
                        if (Integer.valueOf(textField.getText()) > 99) {
                            textField.setText(String.valueOf(99));
                        } else if (Integer.valueOf(textField.getText()) < 0) {
                            textField.setText(String.valueOf(0));
                        }
                    } catch (NumberFormatException e) {
                        textField.setText("0");
                    }      
                });
                textFieldHBox.getChildren().add(textField);
            }
            textFieldHBoxes.add(textFieldHBox);
        }
        
        //Creates buttons to start each sort
        Button selectionSort = new Button("Start Selection Sort");
        Button insertionSort = new Button("Start Insertion Sort");
        Button quickSort = new Button("Start Quick Sort");
        Button mergeSort = new Button("Start Merge Sort");
        
        //Creates labels for all the output steps
        Label lab1 = new Label();
        Label lab2 = new Label();
        Label lab3 = new Label();
        Label lab4 = new Label();
        
        //Adds actions for every button press, calling the sort methods
        selectionSort.setOnAction(a -> {
            try {
                lab1.setText(Algorithms.selectionSort(convertArray(numBoxes.get(0))));
            } catch (NumberFormatException exception) {
                lab1.setText("Input is not valid! Numbers Only!");
            }
        });
        insertionSort.setOnAction(a -> {
            try {
                lab2.setText(Algorithms.insertionSort(convertArray(numBoxes.get(1))));
            } catch (NumberFormatException exception) {
                lab2.setText("Input is not valid! Numbers Only!");
            }
        });
        quickSort.setOnAction(a -> {
            try {
                lab3.setText(Algorithms.quickSort(convertArray(numBoxes.get(2)), 0, 9));
            } catch (NumberFormatException exception) {
                lab3.setText("Input is not valid! Numbers Only!");
            }
        });
        mergeSort.setOnAction(a -> {
            try {
                lab4.setText(Algorithms.mergeSort(convertArray(numBoxes.get(3)), 0, 9));
            } catch (NumberFormatException exception) {
                lab4.setText("Input is not valid! Numbers Only!");
            }
        });
        
        //Puts the buttons in an array
        start.add(selectionSort);
        start.add(insertionSort);
        start.add(quickSort);
        start.add(mergeSort);
        
        //Creates a random generate button for each sort tab
        for (int i = 0; i < 4; i++) {
            randGen.add(new Button("Generate Random Numbers"));
            reset.add(new Button("Reset Numbers"));
            reset.get(i).setOnAction(a -> {
                for (int j = 0; j < numBoxes.size(); j++) {
                    for (TextField text : numBoxes.get(j)) {
                        text.setText("");                
                    }
                }
            });
            randGen.get(i).setOnAction(a -> {
                for (int j = 0; j < numBoxes.size(); j++) {
                    for (TextField text : numBoxes.get(j)) {
                        int num = (rand.nextInt(100));
                        text.setText(String.valueOf(num));
                    }
                }
            });
        }
        
        sortSteps[0] = lab1;
        sortSteps[1] = lab2;
        sortSteps[2] = lab3;
        sortSteps[3] = lab4;
        
        //Adds and aligns the buttons
        for (int i = 0; i < 4; i++){
            HBox hBox = new HBox();
            hBox.getChildren().addAll(randGen.get(i), start.get(i), 
                    reset.get(i));
            hBox.setAlignment(Pos.CENTER);
            buttonArray.add(hBox);
        }
        
        //Adds the label steps into the tab
        for (int i = 0; i < 4; i++){
            tabVBoxes.get(i).getChildren().addAll(tabLabels[i],
                    textFieldHBoxes.get(i),
                    buttonArray.get(i), sortSteps[i]);
        }
        
        //Sets arraylist for all the buttons in each tab
        select.setContent(tabVBoxes.get(0));
        insert.setContent(tabVBoxes.get(1));
        quick.setContent(tabVBoxes.get(2));
        merge.setContent(tabVBoxes.get(3));
        
        sortPane.getTabs().add(intro);
        sortPane.getTabs().add(select);
        sortPane.getTabs().add(insert);
        sortPane.getTabs().add(quick);
        sortPane.getTabs().add(merge);
        
        Scene scene = new Scene(sortPane, 640, 480);
        stage.setScene(scene);
        stage.show();
    }
    
    //Array converts array from String/Textfield array to an integer array
    public int[] convertArray(TextField[] arr) {
        int[] result = new int[arr.length];
        for(int i = 0; i < arr.length; i++) {
            result[i] = Integer.valueOf(arr[i].getText());
        }
        return result;
    }
    
    public static void main(String[] args) {
        launch();
    }

}